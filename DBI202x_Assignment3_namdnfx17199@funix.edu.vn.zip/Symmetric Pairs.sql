select distinct f.x, f.y from 
(select x, y, row_number() over(order by x,y) rn from functions) as f
where f.x in 
(select y from (select x,y, row_number() over(order by x,y) rn from functions ) as f2 
 where f2.x=f.y and f.rn<>f2.rn)
and f.x<= f.y
order by f.x asc