select a.company_code , b.founder, 
count(distinct a.lead_manager_code) lead_manager,
count(distinct a.senior_manager_code) senior_manager,
count(distinct a.manager_code) manager,
count(distinct a.employee_code) employee
from
(
    select * from Employee 
    union all
    select *,null from Manager  
    union all
    select *,null, null from Senior_Manager  
    union all
    select *, null, null, null from Lead_Manager 
) as a, Company as b where a.company_code=b.company_code
group by a.company_code, b.founder 
order by a.company_code