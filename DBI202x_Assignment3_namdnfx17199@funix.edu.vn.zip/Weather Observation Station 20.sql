WITH CTE AS (
    SELECT
        COUNT(*) OVER() total,
        ROW_NUMBER() OVER(ORDER BY LAT_N) number,
        LAT_N lat
    FROM Station
)
SELECT TOP 1
    CAST((SELECT lat FROM CTE WHERE number = total/2+1) AS NUMERIC(9,4))
FROM CTE