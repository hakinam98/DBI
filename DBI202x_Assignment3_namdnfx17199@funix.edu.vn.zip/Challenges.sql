with tbl1 as (select h.hacker_id, h.name, count(challenge_id) as challenges_created 
              from hackers h
             join challenges ch on h.hacker_id = ch.hacker_id
             group by h.hacker_id, h.name),
    tbl2 as (select challenges_created from tbl1
            where challenges_created <> (select max(challenges_created) from tbl1)
            group by challenges_created
            having count(*)>1)
select * from tbl1
where challenges_created not in (select * from tbl2)
order by challenges_created desc, hacker_id
