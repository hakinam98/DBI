select top 1 max(earnings), count(employee_id)
from (select employee_id, (months*salary) as earnings from employee) as EarnTable
group by earnings
order by earnings desc;
