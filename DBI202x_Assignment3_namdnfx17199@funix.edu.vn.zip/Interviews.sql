select c.contest_id,
c.hacker_id,
c.name,
sum(ss.sum_subs),
sum(ss.sum_accepted_subs),
sum(sv.sum_views),
sum(sv.sum_unique_views)
from contests c
join colleges col
on c.contest_id = col.contest_id
join challenges ch
on col.college_id = ch.college_id
left join (select challenge_id, sum(total_views) as sum_views, sum(total_unique_views) as sum_unique_views
          from view_stats
          group by challenge_id) sv
on ch.challenge_id = sv.challenge_id
left join (select challenge_id, sum(total_submissions) as sum_subs, sum(total_accepted_submissions) as sum_accepted_subs
          from submission_stats
           group by challenge_id) ss
on ch.challenge_id = ss.challenge_id
group by c.contest_id,c.hacker_id,c.name
having sum(sv.sum_views)+sum(sv.sum_unique_views)+sum(ss.sum_subs)+sum(ss.sum_accepted_subs) > 0
order by c.contest_id
