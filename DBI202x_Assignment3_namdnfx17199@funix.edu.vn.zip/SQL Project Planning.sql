with tbl as
(select p.start_date, p.end_date
from projects p
left join projects as p1
on p.start_date = p1.end_date
where p1.end_date is null
union all
select tbl.start_date, p2.end_date
from tbl
join projects p2
on tbl.end_date = p2.start_date)
select start_date, max(end_date) from tbl
group by start_date
order by count(end_date), start_date