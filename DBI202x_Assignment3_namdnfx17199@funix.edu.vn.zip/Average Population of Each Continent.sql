select
    co.continent,
    floor(avg(ci.population))
from country co, city ci
where ci.countrycode = co.code
group by co.continent