select ci.NAME from CITY as ci
join COUNTRY as co
on ci.COUNTRYCODE= co.CODE
where co.CONTINENT = 'Africa'