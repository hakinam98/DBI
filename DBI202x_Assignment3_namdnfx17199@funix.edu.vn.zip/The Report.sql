Select 
case 
when Marks > 70 then Name 
else 'NULL' 
end, 
case 
when Marks = 100 then 10 
else Marks/10 +1 
end 
as Grade, Marks From Students Order by Grade desc,Name