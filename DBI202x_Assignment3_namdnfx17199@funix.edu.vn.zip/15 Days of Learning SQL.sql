with tbl1 as (select s.hacker_id,h.name,s.submission_date,count(*) as submissions
             from submissions s
             left join hackers h
             on s.hacker_id=h.hacker_id
             group by s.hacker_id, h.name,s.submission_date),
    tbl2 as (select *, row_number() over (partition by submission_date
                                         order by submissions desc,hacker_id) as rn
             from tbl1),
    tbl3 as (select submission_date,hacker_id, row_number() over (partition by hacker_id
                                                                 order by submission_date) as rn
             from tbl1),
    tbl4 as (select submission_date,count(distinct hacker_id) as hackers
            from tbl3
            where rn=DAY(submission_date)
             group by submission_date)
select tbl4.submission_date,tbl4.hackers, tbl2.hacker_id,tbl2.name from tbl4
left join tbl2 on tbl4.submission_date = tbl2.submission_date
where tbl2.rn  = 1
order by tbl4.submission_date