with tblScore as
(select s.hacker_id,s.challenge_id, max(score) as max_score from Submissions s
group by s.hacker_id,s.challenge_id)

select t.hacker_id, name, sum(max_score) as score from tblScore t
join Hackers h on h.hacker_id = t.hacker_id
group by t.hacker_id, name
having sum(max_score) <>0
order by score desc, hacker_id