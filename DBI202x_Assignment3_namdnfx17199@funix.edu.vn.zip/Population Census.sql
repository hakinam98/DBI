select sum(ci.Population) from CITY as ci
join COUNTRY as co
on ci.Countrycode = co.Code
where co.CONTINENT = 'Asia'